export let config={
    parentdb:'parentsData',
    daycaredb:'userData',
    childdb:'childrenData'
}
export let SERVER_NAME = "myServer.com";
export let TEST_USERNAME = "myName";
